/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package makingBurger;

/**
 *
 * @author bdafahim
 */
public class Noodles extends Decorator {
    Bun bun;

    public Noodles(Bun bun) {
        super(bun);
        
    }

    @Override
    public void add() {
        super.add();
        System.out.println("Burger with noodles is made by keka recipie!");
    
    }
}
