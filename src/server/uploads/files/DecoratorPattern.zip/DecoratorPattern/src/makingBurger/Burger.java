/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package makingBurger;

import sun.font.Decoration;

/**
 *
 * @author bdafahim
 */
public class Burger extends Decorator{
    private int price;

    public Burger(int price) {
        this.price = price;
    }

    @Override
    public void add() {
        System.out.println("Burger is made! plz pay the prize "+price); //To change body of generated methods, choose Tools | Templates.
    }
  
    
}
